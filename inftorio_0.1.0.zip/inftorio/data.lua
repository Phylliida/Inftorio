--data.lua

require("prototypes.recipe")
require("prototypes.item.item")
